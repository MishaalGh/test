//Name: Mishaal Ghumman 
//Student ID: 100831093 
//Date: November 5th, 2024 
import express from "express";
import routes  from "./routes/routes.js";
const app = express();
const port = process.env.PORT || 8080;

//ejs setup
app.set("view engine", "ejs");
app.set("views", "./views");

//routes
app.use(routes);
app.get("/", (req, res) => {
    res.send("Hello World!");
})

app.listen(port, () => console.log(`Server running on port ${port}`));